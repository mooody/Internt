/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.persistence.*;
import org.hibernate.Session;
import play.Logger;
import play.db.jpa.JPA;
import play.db.jpa.Model;

/**
 *
 * @author mikael
 */

@Entity
/*@SqlResultSetMapping(
		name="t",
        entities=@EntityResult(entityClass=DataSeriePost.class,
			fields = {	
				@FieldResult(name="num", column = "num")
			}),
        columns = { @ColumnResult(name = "sum") } )

@NamedNativeQuery(name="test",
    query="select p.num, sum(p.up) as sum from DataSeriePost p group by p.num", 
    resultSetMapping="test")
*/
public class DataSeriePost extends Model{
	public double up;
	public double down;
	@Temporal(TemporalType.TIMESTAMP)
	public Date date;
	public int num;
	
	public double getSum(){
		return this.up+this.down;
	}
	@Override
	public String toString(){
		return "["+this.num+"]"+(this.up+this.down) +" "+ new SimpleDateFormat("yyyy-MM-dd").format(this.date);
	}
	
	//HighChart
	public static String getChartDataSerieByNum(int _num) throws ParseException
	{
		List<List<DataSeriePost>> posts = new ArrayList<List<DataSeriePost>>();
		//hämta ut per månad i databasen
		for(int i=0; i<12; i++)
		{
				List<DataSeriePost> temp = DataSeriePost.find("select p from DataSeriePost p where p.num = :num and p.date between :start and :stop order by date asc, num asc")
				.bind("num", _num)
				.bind("start",new SimpleDateFormat("yyyy-MM-dd").parse("2013-"+i+"-01"))
				.bind("stop",new SimpleDateFormat("yyyy-MM-dd").parse("2013-"+i+"-31")).
				fetch();
		
				posts.add(temp);
		}
		
		String response = "{ name: '"+_num+"', data: []";
		return response;
	}
	public static SortedMap<String, String> getChartDataPerNum(List<Integer> nums, Map<String, List<Integer>> groups) throws SQLException, ParseException{
	
		List<Integer> grupp = new ArrayList<Integer>();
		grupp.add(2);
		grupp.add(3);
		EntityManager em = JPA.em();
		
		List<List<Object[]>> posts = new ArrayList<List<Object[]>>();
		
		//hämta ut per månad i databasen
		Date start = new Date();
		int iPosts = 0;
		for(int i=1; i<=12; i++)
		{
				Query query = em.createNativeQuery("select p.num, sum(p.up) from DataSeriePost p where p.num in (:nums) and p.date between :start and :stop group by p.num order by p.num")
				.setParameter("nums", nums)
				.setParameter("start",new SimpleDateFormat("yyyy-MM-dd").parse("2013-"+i+"-01"))
				.setParameter("stop",new SimpleDateFormat("yyyy-MM-dd").parse("2013-"+i+"-31"));
		
				List<Object[]> templist = query.getResultList();

				List<Object[]> result = new ArrayList<Object[]>();
				for(Integer k:nums)
				{
					Object[] temp = new Object[2];
					boolean found = false;
					
					for(Object[] obj: templist)
					{	
						for(int j = 0; j<obj.length; j++)
						{
							if(obj[0] == k)
							{
								found=true;
								temp[0] = obj[0];
								temp[1] = obj[1];
							}
						}
					}
					
					if(!found)
					{
						temp[0] = (Object)k;
						temp[1] = (Object)0;
					}

					result.add(temp);
				}
				posts.add(result);
				//Snabbar detta på om det är mycket data???
				/*em.flush();
				em.getTransaction().commit();
				em.clear();
				if(i<12)
				{
					em.getTransaction().begin();
				}*/
		}
		Date stop = new Date();
		Long time = stop.getTime() - start.getTime();
		Logger.info("%s ms %s", time,iPosts);
		
		SortedMap<String, String> chartData = new TreeMap<String, String>();
		
		for(int i=0; i<12; i++)
		{
			
			for(Object[] t: posts.get(i))
			{
				String key = getGroupKey(groups, (Integer)t[0]);

				if(chartData.containsKey(key))
				{
					String data = chartData.get(key);
					String[] dataArr = data.split(",");

					//om det redan finns ett värde på platsen
					if(dataArr.length==i+1)
					{
						//hämta ny data
						Number tData = (Number)t[1];
						//hämta sista inlagda data
						String oldData = dataArr[dataArr.length-1];
						//addera nya datat
						tData = (Number)(tData.doubleValue() + Double.parseDouble(oldData));
						data = "";
						//skriv tillbaka gammal oförändrad data
						for(int index = 0; index<dataArr.length-1;index++)
						{
							data+=dataArr[index]+",";
						}
						//lägg till det nyberäknade datat
						data+=tData;
						chartData.put(key, data);
					}
					else
					{
						chartData.remove(key);
						Number tData = (Number)t[1];
						chartData.put(key, data+","+tData);
					}
				}
				else
				{
					chartData.put(key, ""+t[1]);
				}
			}
		}	
		
		
		return chartData;
		
	}
	
	private static String getGroupKey(Map<String, List<Integer>> groups, Integer num)
	{
		if(groups != null)
		{
			for(String key: groups.keySet())
			{
				if(groups.get(key).contains(num))
				{
					return key;
				}
			}
		}
		return ""+num;
	}
	

	
	

	public class Test
	{
		public long id;
		public Integer num;
		public Double sum;
	}
	public static String getChartData() throws ParseException
	{
	
		List<List<DataSeriePost>> posts = new ArrayList<List<DataSeriePost>>();
		//hämta ut per månad i databasen
		for(int i=0; i<12; i++)
		{
				List<DataSeriePost> temp = DataSeriePost.find("select p from DataSeriePost p where p.date between :start and :stop order by date asc, num asc")
				.bind("start",new SimpleDateFormat("yyyy-MM-dd").parse("2013-"+i+"-01"))
				.bind("stop",new SimpleDateFormat("yyyy-MM-dd").parse("2013-"+i+"-31")).
				fetch();
		
				posts.add(temp);
		}
		
		//innehåller månad, nummer, värde
		SortedMap<Integer, SortedMap<Integer,Double>> months = new TreeMap<Integer, SortedMap<Integer,Double>>();
		
		//nummer,värde
		SortedMap<Integer, Double> sums; 
		
		play.Logger.info("Series: %s", posts.size()); 
		int month = 1;
		for(List<DataSeriePost> postlist: posts){
			
			//första månadens värden
			sums = new TreeMap<Integer, Double>();
			for(DataSeriePost post: postlist){
				play.Logger.info(post.toString());
				//summera alla värden
				if(!sums.containsKey(post.num))
					sums.put(post.num,0d);
				
				Double temp = sums.get(post.num)+post.getSum();	
				sums.remove(post.num);
				sums.put(post.num, temp);
			}
			
			//lägg i månadsposter
			months.put(month, sums);
			month++;
		}
		

		for(Map<Integer,Double> summa: months.values())
		{
				Logger.info("----------------------------------");
			for(Integer integer: summa.keySet())
			{
				Logger.info("%s %s", integer, summa.get(integer));
			}
		}
		/*
		int sum = 0;
		for(int i=1; i<12; i++)
		{
			//hämta ut månader
			Map<Integer,Double> summa = months.get(i);
			if(summa != null)
			{
				for(Integer integer: summa.keySet())
				{
					//data[i+1] = String.format("name:'%s', data[]")
					//Logger.info("Månad %s = %s %s",i, integer, summa.get(integer));
					sum++;
				}
			}
			else
			{
				//Logger.info("Månad %s = 0",i);
			}
		}*/
		return "";
	}
}
