/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import javax.persistence.Entity;
import play.db.jpa.Model;

/**
 *
 * @author mikael
 */
@Entity
public class DataClass extends Model {
	String url;
	public String getUrl(){return this.url;}
	
	public DataClass(String _url)
	{
		this.url = _url;
	}
	
}
