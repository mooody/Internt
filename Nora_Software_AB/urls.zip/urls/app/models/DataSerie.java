/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.util.List;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import play.db.jpa.Model;

/**
 *
 * @author mikael
 */
@Entity
public class DataSerie extends Model{
	@OneToMany
	public List<DataSeriePost> posts;
	public String name;
	public DataSerie(String _name){
		this.name = _name;
	}
	
	public String getChartDataString(){
		
		StringBuilder sb = new StringBuilder();
		for(int i=0; i<this.posts.size(); i++){
			sb.append(this.posts.get(i).toString());
			if((i+1)<this.posts.size())
			{
				sb.append(",");
			}
		}
		
		return sb.toString();
	}
}
