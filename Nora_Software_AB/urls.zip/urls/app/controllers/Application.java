package controllers;


import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.persistence.Query;
import play.mvc.*;
import play.Logger;
import models.*;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import play.db.jpa.JPA;
import play.mvc.Http.Cookie;
import play.mvc.Http.Header;




public class Application extends Controller {

	public static void index() 
	{
		
		 Query query = JPA.em().createNativeQuery("select distinct d.num from DataSeriePost d");
		 List<Number> posts = (List<Number>)query.getResultList();
		 
		//SortedMap<String, String> chartData = DataSeriePost.getChartDataPerNum();
		//Logger.info("%s",DataSeriePost.getChartData());
		render(posts);
	}
	
	public static void drawChart(List<Integer> list)throws ParseException, SQLException
	{
		Map<String, String[]> map = params.sub("grupp");
		
		Map<String, List<Integer>> groups = new TreeMap<String, List<Integer>>();
		for(String key : map.keySet())
		{
			if(!key.isEmpty())
			{
				play.Logger.info("%s %s", key, map.get(key).length);
				List<Integer> nums = new ArrayList<Integer>();
				for(int i=0; i<map.get(key).length; i++)
				{
					play.Logger.info(map.get(key)[i]);
					nums.add(Integer.parseInt(map.get(key)[i]));
				}
				groups.put(key, nums);
			}
		}
		
		
		
		Logger.info("%s", map.toString());
		 Query query = JPA.em().createNativeQuery("select distinct d.num from DataSeriePost d");
		 List<Number> posts = (List<Number>)query.getResultList();
		 
		String type = params.get("charttype")==null?"column":params.get("charttype");

		
		SortedMap<String, String> chartData = DataSeriePost.getChartDataPerNum(list, groups);
		//Logger.info("%s",DataSeriePost.getChartData());
		render("Application/index.html",chartData, type, posts, list,groups);
	}
	private static String generateDateString(){
		Random rand = new Random();
		int month = rand.nextInt(12)+1;
		int day = rand.nextInt(31)+1;
		String month_str = month>9?""+month:"0"+month;
		String day_str = day>9?""+day:"0"+day;
		return ("2013-"+month_str+"-"+day_str);
	}
	public static void go1() throws IOException, ParseException, SQLException
	{
		for(int i = 0; i<1000; i++)
		{
			DataSeriePost post;

			
			Random rand = new Random();
			
			double value = 100;//((rand.nextDouble()-0.5) * 10000);
			if(value>0)
			{	post = new DataSeriePost();
				post.up = value;
			}
			else if(value<0)
			{	post = new DataSeriePost();
				post.down = value;
			}
			else{
				continue;
			}
			post.num = rand.nextInt(10);
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			post.date = formatter.parse(generateDateString());
		
			play.Logger.info("-- New Post Created num %s", post.num);
			post.save();
		}
		
		/*Map<String, Header> map = Controller.request.headers;
		
		for(String key : map.keySet())
		{
			Header head = map.get(key);

			play.Logger.info(" * "+head.name);
			for(String value: head.values)
			{
				play.Logger.info(" - "+value);
			}
			
			play.Logger.info("\n\n");
		}
		
		Map<String, Cookie> cooks = Controller.request.cookies;
		
		for(String key : cooks.keySet())
		{
			Cookie cookie = cooks.get(key);

			printCookie(cookie);
		}
		
		//Logger.info("Size of request %s", sizeOf(Controller.request));
		Logger.info("Size of header %s", sizeOf(Controller.request.headers));
		Logger.info("Size of cookies %s", sizeOf(Controller.request.cookies));
		Logger.info("Size of args %s", sizeOf(Controller.request.args));
		*/
		index();
	}
	
	private static void printCookie(Cookie cookie) throws IOException
	{
	/*	Logger.info("------------Size: %s -----------", sizeOf(cookie));
		Logger.info("%s : %s",cookie.name, cookie.value);

		Logger.info("domain %s",cookie.domain);
		Logger.info("path %s",cookie.path);
		Logger.info("httpOnly %s",cookie.httpOnly);
		Logger.info("secure %s",cookie.secure);
		Logger.info("sendOnError %s",cookie.sendOnError);
		Logger.info("maxAge %s",cookie.maxAge);
		Logger.info("\n----------------");*/
	}
	
	private static void printHeader(Header head) throws IOException
	{
		Logger.info("------------Size: %s -----------", sizeOf(head));
		Logger.info("%s", head.name);
		for(String value: head.values)
		{
			play.Logger.info(" - "+value);
		}
		
	}
	
	private static void printBody()
	{
	}
	
	public static int sizeOf(Object obj) throws java.io.IOException
	{
		ByteArrayOutputStream byteObject = new ByteArrayOutputStream();
		ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteObject);
		objectOutputStream.writeObject(obj);
		objectOutputStream.flush();
		objectOutputStream.close();
		byteObject.close();

		return byteObject.toByteArray().length;
	}
	
	public static void done(){}



}