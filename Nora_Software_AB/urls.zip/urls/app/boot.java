
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;
import models.DataSerie;
import models.DataSeriePost;
import play.Logger;
import play.jobs.Job;
import play.jobs.OnApplicationStart;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

@OnApplicationStart
public class boot  extends Job{
	@Override
	public void doJob() throws ParseException{
		
		if(DataSeriePost.count()>0) return;
		/*
		Random rand = new Random();
		DataSerie serie = new DataSerie(generateName());
		play.Logger.info("New Serie");
		for(int i=1; i<13; i++)
		{
			DataSeriePost post;
			double value = ((rand.nextDouble()-0.5) * 10000);
			if(value>0)
			{	post = new DataSeriePost();
				post.up = value;
			}
			else if(value<0)
			{	post = new DataSeriePost();
				post.down = value;
			}
			else{
				continue;
			}
			
			play.Logger.info("-- New Post");
			post.save();
			if(serie.posts == null) serie.posts = new ArrayList<DataSeriePost>();
			serie.posts.add(post);
			if((i)%3==0)
			{
				play.Logger.info("New Serie");
				serie.save();
				serie = new DataSerie(generateName());
			}
		}*/
		
		
		for(int i = 1; i<=12; i++)
		{
			DataSeriePost post;

			
			Random rand = new Random();
			
			double value = 1;//((rand.nextDouble()-0.5) * 10000);
			
			for(int num=1; num<10; num++)
			{
				post = new DataSeriePost();
				post.up = value;

				post.num = num;

				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
				post.date = formatter.parse(generateDateString(i));

				play.Logger.info("-- New Post Created num %s, %s, %s", post.num, post.date, post.up);
				post.save();
			}
		}
	}
	private String generateDateString(int month){
		Random rand = new Random();
		//int month = rand.nextInt(12)+1;
		int day = rand.nextInt(31)+1;
		String month_str = month>9?""+month:"0"+month;
		String day_str = day>9?""+day:"0"+day;
		return ("2013-"+month_str+"-"+day_str);
	}
	private String generateName()
	{
		String letters = "ABCDEFGHIJKLMNOPQRSTUVXYZÅÄÖ";
		String name = "";
		
		Random rand = new Random();
		for(int i = 0; i< 5; i++)
		{
			name+=letters.charAt(rand.nextInt(letters.length()));
		}
		
		return name;
	}
}
